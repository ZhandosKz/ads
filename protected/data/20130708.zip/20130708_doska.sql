-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июл 08 2013 г., 00:57
-- Версия сервера: 5.5.27-log
-- Версия PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `doska`
--

-- --------------------------------------------------------

--
-- Структура таблицы `ads`
--

CREATE TABLE IF NOT EXISTS `ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `is_published` tinyint(4) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=393 ROW_FORMAT=FIXED AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `ads`
--

INSERT INTO `ads` (`id`, `user_id`, `alias`, `title`, `description`, `is_published`, `created_at`, `created_by`, `modified_at`, `modified_by`) VALUES
(1, NULL, 'kotenok-1', 'Котёнок', '<p>3 года</p>\r\n\r\n<p>вес 100 кг, откормленный</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin et venenatis lectus, ac gravida turpis. Ut nec mauris id urna blandit iaculis vel a odio. Suspendisse potenti. Aenean porttitor nunc sapien, vel euismod lorem auctor non. In hac habitasse platea dictumst. Nulla vehicula viverra enim, non malesuada elit luctus et. Donec sit amet pharetra massa. Nulla gravida metus eu ipsum imperdiet, quis pulvinar leo ultrices. Curabitur sed suscipit mauris, eget imperdiet nulla.</p>\r\n\r\n<p>Proin ut ante egestas, rhoncus leo ut, imperdiet lorem. Curabitur metus tellus, lacinia eu lectus ac, cursus laoreet lacus. Etiam vitae massa feugiat, laoreet ipsum non, vehicula turpis. Pellentesque elementum, magna eget lobortis ornare, purus justo venenatis nulla, eget fermentum magna massa et odio. Donec vel lacus sit amet metus fermentum consectetur id sit amet nisl. Integer at nisi in felis consequat euismod. Aenean quis pulvinar nunc, id rhoncus lacus. Nulla laoreet, orci vitae aliquet molestie, nisl velit fermentum urna, eget sodales enim ligula id erat. In commodo ligula tellus, quis fermentum tortor auctor vel. Nam faucibus diam odio, nec commodo tortor rutrum vel.</p>\r\n\r\n<p>Duis venenatis placerat nisl quis porttitor. Mauris ornare tincidunt nisl mollis imperdiet. Sed dapibus porta nunc, at tristique velit eleifend non. Aliquam at bibendum massa. Phasellus tortor neque, rutrum sit amet facilisis sit amet, bibendum in velit. Duis a libero eget lorem pharetra tincidunt et sit amet nibh. Sed in tortor elementum, vulputate leo a, laoreet turpis. Vestibulum ullamcorper lacus varius lobortis pharetra. Donec rhoncus sem cursus nibh commodo, in commodo elit iaculis. Sed nec interdum augue. Curabitur rutrum iaculis nunc vel adipiscing. Maecenas tincidunt purus ut velit tincidunt, non tempus erat bibendum. Phasellus ut convallis metus. Vestibulum at libero elementum, mattis mauris et, pharetra eros.</p>\r\n\r\n<p>Ut imperdiet purus vulputate, dapibus urna in, ultrices purus. Sed vitae lacinia nulla, et blandit leo. Donec bibendum sapien nisi, sed feugiat erat aliquet at. Ut suscipit, nibh sed pellentesque porta, tortor magna ultricies elit, pretium pellentesque sapien turpis non nibh. Etiam ac nisi sit amet urna fringilla venenatis. Praesent pharetra vel purus id pretium. Aliquam erat volutpat.</p>\r\n', 1, '2013-07-07 16:51:35', 23, '2013-07-07 23:27:02', 23),
(2, 25, 'prodam-kota', 'продам кота', '<p>екеукеу</p>\r\n', 1, '2013-07-07 19:49:19', 25, NULL, NULL),
(3, 25, 'prodam-kota-1', 'продам кота', '<p>ghfghfh</p>\r\n', 1, '2013-07-07 20:04:59', 25, NULL, NULL),
(4, 25, 'prodam-kota-2', 'продам кота', '<p>jhhhjhjhgjh</p>\r\n', 1, '2013-07-07 20:05:24', 25, NULL, NULL),
(5, 25, 'kuplyu-porosenka', 'куплю поросёнка', '<p>описание поросёнка</p>\r\n', 1, '2013-07-07 22:06:38', 25, NULL, NULL),
(6, 25, 'prodam-kotaaaaa', 'продам котааааа', '<p>ееееуккпппппе</p>\r\n', 1, '2013-07-07 22:11:25', 25, NULL, NULL),
(7, 26, 'prodam-kotaaaaa-1', 'продам котааааа', '<p>fdfdsfdsfsd</p>\r\n', 1, '2013-07-07 22:12:22', 26, NULL, NULL),
(8, 26, 'prodam-kotaaaaa-2', 'продам котааааа', '<p>fdsfdsfds</p>\r\n', 1, '2013-07-07 22:14:47', 26, NULL, NULL),
(9, 27, 'prrr-kota', 'prrr кота', '<p>fdfdddsfdsdfdsfsfds</p>\r\n', 1, '2013-07-08 00:15:13', 27, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `ads_category`
--

CREATE TABLE IF NOT EXISTS `ads_category` (
  `ads_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `ads_category`
--

INSERT INTO `ads_category` (`ads_id`, `category_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(9, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `AuthAssignment`
--

CREATE TABLE IF NOT EXISTS `AuthAssignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthAssignment`
--

INSERT INTO `AuthAssignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('superadmin', '23', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItem`
--

CREATE TABLE IF NOT EXISTS `AuthItem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthItem`
--

INSERT INTO `AuthItem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('superadmin', 2, '', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItemChild`
--

CREATE TABLE IF NOT EXISTS `AuthItemChild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `alias`, `name`, `description`, `created_at`, `created_by`, `modified_at`, `modified_by`) VALUES
(1, 'prodam', 'Продам', '<p>продажа котят и собак</p>\r\n', '2013-07-07 16:50:12', 23, NULL, NULL),
(2, 'kuplyu', 'Куплю', '<p>Покупка поросят</p>\r\n', '2013-07-07 16:50:41', 23, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `commentary`
--

CREATE TABLE IF NOT EXISTS `commentary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_alias` varchar(255) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `text` text,
  `author_name` varchar(255) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `is_published` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `content_view`
--

CREATE TABLE IF NOT EXISTS `content_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_alias` varchar(255) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `user_cookie` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `field`
--

CREATE TABLE IF NOT EXISTS `field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(5000) DEFAULT NULL,
  `object_alias` varchar(255) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sms_transaction`
--

CREATE TABLE IF NOT EXISTS `sms_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `user_cookie` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `salt`) VALUES
(23, 'admin', '37e458e1fd4332305d95818853acb302', 'zhandos.90@gmail.com', 'j0s7f7o0sxx2tehb2dk6n04p34fakudx'),
(26, 'zzz@zzzzz.com', 'dee09168aa3b39b9812e00bdd13a51e5', 'zzz@zzzzz.com', 'drywtxxaxqy7ehivf2ktrrm4kgkfohxr'),
(27, 'zzz@zaaaazz.com', '1f77824f262c4e72b58de423783aa2c9', 'zzz@zaaaazz.com', 'bvv57gwmmqsxjyc5ovwp2pdja3z6fcqk');

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `AuthAssignment`
--
ALTER TABLE `AuthAssignment`
  ADD CONSTRAINT `authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `AuthItemChild`
--
ALTER TABLE `AuthItemChild`
  ADD CONSTRAINT `authitemchild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `authitemchild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
